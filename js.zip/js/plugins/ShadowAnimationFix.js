(function() {
  const _updateFlash = Sprite_Animation.prototype.updateFlash;
  Sprite_Animation.prototype.updateFlash = function() {
    _updateFlash.call(this);
    if (this._flashDuration === 0) {
	  for (const target of this._targets) {
		const blend = target.getBlendColor();
		target.setBlendColor([0, 0, 0, blend[3]]);
	  }
	}
  };
})();