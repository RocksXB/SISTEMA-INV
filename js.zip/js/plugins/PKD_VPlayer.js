/*:
 * @plugindesc (v2.0)[PRO] Extended WEBM Video Player - Fixed
 * @author Pheonix KageDesu (fixed by Ottogi)
 * @url https://kdworkshop.net/plugins/vplayer/
 * @target MZ MV
 *
 * @help
 * Drop-in replacement for PKD_VPlayer that fixes video looping bugs.
 * Uses native video events instead of polling for reliable playback control.
 * 
 * This version maintains compatibility with all existing PKD_VPlayer commands
 * but uses a cleaner architecture that prevents the video restart bug.
 *
 * @command ShowVAnim
 * @text Show Animation
 * @desc Show video animation
 * 
 * @arg id
 * @text ID (File name)
 * @desc .webm file name in movies folder
 * @type text
 * @default 1
 * 
 * @arg order
 * @text Order
 * @type select
 * @option Screen, above windows
 * @option Screen, below windows
 * @option Screen, below pictures
 * @option Map, above Events
 * @option Map, below Events
 * @default Screen, above windows
 * 
 * @arg x
 * @text X
 * @type number
 * @default 0
 * 
 * @arg y
 * @text Y
 * @type number
 * @default 0
 * 
 * @arg isLoop
 * @text Is Looping?
 * @type boolean
 * @on Looping
 * @off Play Once
 * @default true
 * 
 * @command DeleteVAnim
 * @text Delete Animation
 * @desc Delete video animation
 * 
 * @arg id
 * @text ID (File name)
 * @type text
 * @default 1
 * 
 * @command SetEndCallToAnim
 * @text Set End Action
 * @desc Add script or common event call when animation ends
 * 
 * @arg id
 * @text ID (File name)
 * @type text
 * @default 1
 * 
 * @arg script
 * @text Script
 * @type text
 * @default
 * 
 * @arg commonEvent
 * @text Common Event
 * @type common_event
 * @default 0
 * 
 * @arg isLast
 * @text Last action?
 * @type boolean
 * @default false
 * 
 * @command SetTimeCallToAnim
 * @text Add Time Action
 * @desc Execute script or common event at specific time
 * 
 * @arg id
 * @text ID (File name)
 * @type text
 * @default 1
 * 
 * @arg time
 * @text Time
 * @desc Time in frames (60 = 1 second)
 * @type number
 * @default 60
 * 
 * @arg script
 * @text Script Call
 * @type text
 * @default
 * 
 * @arg commonEvent
 * @text Common Event
 * @type common_event
 * @default 0
 */

(function() {
    'use strict';

    const pluginName = 'PKD_VPlayer';

    // Store active videos by ID
    const activeVideos = new Map();

    // Video controller class using PIXI
    class VideoController extends PIXI.Container {
        constructor(id, filename, isLoop) {
            super();
            this.id = id;
            this.filename = filename;
            this.isLoop = isLoop;
            this.videoTexture = null;
            this.videoSprite = null;
            this.videoElement = null;
            this.timeActions = [];
            this.endAction = null;
            this.lastCheckedTime = 0;
            this.hasEnded = false;
            this.loaded = false;
        }

        create() {
            return new Promise((resolve, reject) => {
                try {
                    // Create PIXI video texture
                    if (Utils.RPGMAKER_NAME === "MV") {
                        this.videoTexture = PIXI.Texture.fromVideo(`movies/${this.filename}.webm`);
                    } else {
                        this.videoTexture = PIXI.Texture.from(`movies/${this.filename}.webm`);
                    }

                    // Create sprite from texture
                    this.videoSprite = new PIXI.Sprite(this.videoTexture);

                    // Wait for video to load
                    this.videoTexture.baseTexture.on('loaded', () => {
                        this.onTextureLoaded();
                        resolve();
                    });

                    this.videoTexture.baseTexture.on('error', (err) => {
                        reject(new Error(`Failed to load video: ${this.filename}`));
                    });

                } catch (err) {
                    reject(err);
                }
            });
        }

        onTextureLoaded() {
            // Get the actual video element
            this.videoElement = this.getVideoSource();
            if (!this.videoElement) {
                console.error(`Could not get video source for ${this.id}`);
                return;
            }

            // Set loop
            this.videoElement.loop = this.isLoop;

            // Apply game variable settings
            this.updateSettings();

            // Scale video to fit screen
            const targetW = Graphics.width;
            const targetH = Graphics.height;
            const vidW = this.videoElement.videoWidth;
            const vidH = this.videoElement.videoHeight;
            const scale = Math.min(targetW / vidW, targetH / vidH);
            
            this.videoSprite.width = vidW * scale;
            this.videoSprite.height = vidH * scale;
            this.videoSprite.x = (targetW - this.videoSprite.width) / 2;
            this.videoSprite.y = (targetH - this.videoSprite.height) / 2;

            // Add sprite to container
            this.addChild(this.videoSprite);

            // Setup event listeners
            this.videoElement.addEventListener('ended', () => {
                this.onVideoEnded();
            });

            this.videoElement.addEventListener('timeupdate', () => {
                this.checkTimeActions();
            });

            this.loaded = true;

            // Start playback
            const playPromise = this.videoElement.play();
            if (playPromise) {
                playPromise.catch(err => console.warn('Play failed:', err));
            }
        }

        getVideoSource() {
            if (Utils.RPGMAKER_NAME === "MV") {
                return this.videoTexture.baseTexture.source;
            } else {
                if (this.videoTexture.baseTexture.resource) {
                    return this.videoTexture.baseTexture.resource.source;
                }
            }
            return null;
        }

        updateSettings() {
            if (!this.videoElement) return;

            // Variable 65: Volume (0-100)
            const volumeMultiplier = $gameVariables.value(65) || 100;
            const masterVolume = ConfigManager.masterVolume || 100;
            this.videoElement.volume = (volumeMultiplier / 100) * (masterVolume / 100);

            // Variable 66: Playback speed
            const speedValue = $gameVariables.value(66);
            if (speedValue === "medium") {
                this.videoElement.playbackRate = 1.5;
            } else if (speedValue) {
                this.videoElement.playbackRate = speedValue;
            } else {
                this.videoElement.playbackRate = 1.0;
            }
        }

        update() {
            if (!this.loaded) return;
            
            // Update the video texture
            if (this.videoTexture && this.videoTexture.baseTexture) {
                this.videoTexture.baseTexture.update();
            }
        }

        checkTimeActions() {
            if (!this.videoElement || this.timeActions.length === 0) return;

            const currentTime = this.videoElement.currentTime;
            
            // Check if we've crossed any time action thresholds
            for (let i = this.timeActions.length - 1; i >= 0; i--) {
                const action = this.timeActions[i];
                
                // Convert frames to seconds (assuming 60fps)
                const triggerTime = action.time / 60;
                
                // Fire if we've reached or passed the trigger time
                if (currentTime >= triggerTime && this.lastCheckedTime < triggerTime) {
                    this.executeAction(action);
                    
                    // Remove one-time actions for non-looping videos
                    if (!this.isLoop) {
                        this.timeActions.splice(i, 1);
                    }
                }
            }
            
            this.lastCheckedTime = currentTime;
        }

        executeAction(action) {
            try {
                if (action.script) {
                    eval(action.script);
                }
                if (action.commonEventId) {
                    $gameTemp.reserveCommonEvent(action.commonEventId);
                }
            } catch (err) {
                console.error(`Error executing time action for video ${this.id}:`, err);
            }
        }

        onVideoEnded() {
            // Mark as ended to prevent any restart attempts
            this.hasEnded = true;

            // Execute end action if set
            if (this.endAction) {
                try {
                    if (this.endAction.script) {
                        eval(this.endAction.script);
                    }
                    if (this.endAction.commonEventId) {
                        $gameTemp.reserveCommonEvent(this.endAction.commonEventId);
                    }
                    
                    // Delete if requested
                    if (this.endAction.deleteAfter) {
                        this.destroy();
                    }
                } catch (err) {
                    console.error(`Error executing end action for video ${this.id}:`, err);
                }
            }
        }

        addTimeAction(timeInFrames, script, commonEventId) {
            this.timeActions.push({
                time: timeInFrames,
                script: script,
                commonEventId: commonEventId
            });
            
            // Sort by time to make checking more efficient
            this.timeActions.sort((a, b) => a.time - b.time);
        }

        setEndAction(script, commonEventId, deleteAfter) {
            this.endAction = {
                script: script,
                commonEventId: commonEventId,
                deleteAfter: deleteAfter
            };
        }


		setClickAction(script, commonEventId, isDelete) {
            this.interactive = true;
            if (this.videoSprite) this.videoSprite.interactive = true;

            this.on('pointerdown', () => {
                try {
                    if (script) eval(script);
                    if (commonEventId) $gameTemp.reserveCommonEvent(commonEventId);
                    if (isDelete) this.destroy();
                } catch (err) {
                    console.error(`Error executing click action for video ${this.id}:`, err);
                }
            });
        }
        destroy() {
            if (this.videoElement) {
                this.videoElement.pause();
                this.videoElement.src = '';
            }
            if (this.parent) {
                this.parent.removeChild(this);
            }
            activeVideos.delete(this.id);
            super.destroy({ children: true, texture: true, baseTexture: true });
        }
    }

    // Plugin Commands (MZ)
    if (Utils.RPGMAKER_NAME === "MZ") {
        PluginManager.registerCommand(pluginName, "ShowVAnim", args => {
            const id = args.id || "default";
            const isLoop = args.isLoop === "true" || args.isLoop === true;
            const order = args.order || "Screen, above windows";
            
            // Delete existing video with same ID
            if (activeVideos.has(id)) {
                activeVideos.get(id).destroy();
            }

            // Create video controller
            const video = new VideoController(id, id, isLoop);
            activeVideos.set(id, video);
            
            // Add to the scene
            video.create().then(() => {
                const scene = SceneManager._scene;
                if (!scene) return;
                
                // Match the original plugin's logic exactly
                if (order.includes('below windows')) {
                    // Add to spriteset (below window layer)
                    if (scene._spriteset) {
                        scene._spriteset.addChild(video);
                    }
                } else if (order.includes('below pictures')) {
                    // Add to special layer below pictures
                    if (scene._spriteset && scene._spriteset.__animLayerBelowPics) {
                        scene._spriteset.__animLayerBelowPics.addChild(video);
                    } else if (scene._spriteset) {
                        scene._spriteset.addChild(video);
                    }
                } else if (order.includes('Map, below')) {
                    // Map layer below events
                    if (scene._spriteset) {
                        scene._spriteset.addChild(video);
                    }
                } else if (order.includes('Map, above')) {
                    // Map layer above events
                    if (scene._spriteset) {
                        scene._spriteset.addChild(video);
                    }
                } else {
                    // Default: above windows
                    scene.addChild(video);
                }
            }).catch(err => {
                console.error(err);
                activeVideos.delete(id);
            });
        });

		PluginManager.registerCommand(pluginName, "SetClickToAnim", args => {
            const id = args.id || "default";
            const script = args.script || "";
            const commonEventId = parseInt(args.commonEvent) || 0;
            const isDelete = args.isDelete === "true" || args.isDelete === true;
            
            if (activeVideos.has(id)) {
                activeVideos.get(id).setClickAction(script, commonEventId, isDelete);
            }
        });

        PluginManager.registerCommand(pluginName, "DeleteVAnim", args => {
            const id = args.id || "default";
            
            if (activeVideos.has(id)) {
                activeVideos.get(id).destroy();
            }
        });

        PluginManager.registerCommand(pluginName, "SetTimeCallToAnim", args => {
            const id = args.id || "default";
            const time = parseInt(args.time) || 0;
            const script = args.scriptCall || args.script || "";
            const commonEventId = parseInt(args.commonEvent) || 0;
            
            if (activeVideos.has(id)) {
                activeVideos.get(id).addTimeAction(time, script, commonEventId);
            }
        });
		
		PluginManager.registerCommand(pluginName, "AddAction", args => {
            const id = args.id || "default";
            const time = parseInt(args.time) || 0;
            const script = args.scriptCall || args.script || "";
            const commonEventId = parseInt(args.commonEvent) || 0;
            
            if (activeVideos.has(id)) {
                activeVideos.get(id).addTimeAction(time, script, commonEventId);
            }
        });

        PluginManager.registerCommand(pluginName, "SetEndCallToAnim", args => {
            const id = args.id || "default";
            const script = args.scriptCall || args.script || "";
            const commonEventId = parseInt(args.commonEvent) || 0;
            const deleteAfter = args.isLast === "true" || args.isLast === true;
            
            if (activeVideos.has(id)) {
                activeVideos.get(id).setEndAction(script, commonEventId, deleteAfter);
            }
        });
    }

    // Update all videos each frame
    const _Scene_Base_update = Scene_Base.prototype.update;
    Scene_Base.prototype.update = function() {
        _Scene_Base_update.call(this);
        
        // Update all active videos
        activeVideos.forEach(video => {
            video.update();
        });
    };

    // Create custom sprite layers like the original plugin
    const _Spriteset_Base_createPictures = Spriteset_Base.prototype.createPictures;
    Spriteset_Base.prototype.createPictures = function() {
        // Layer BELOW pictures
        this.__animLayerBelowPics = new Sprite();
        this.addChild(this.__animLayerBelowPics);
        
        // Create pictures (original function)
        _Spriteset_Base_createPictures.call(this);
        
        // Layer ABOVE pictures
        this.__animLayer = new Sprite();
        this.addChild(this.__animLayer);
    };

    // Update settings when variables change
    const _Game_Variables_setValue = Game_Variables.prototype.setValue;
    Game_Variables.prototype.setValue = function(variableId, value) {
        _Game_Variables_setValue.call(this, variableId, value);
        
        // Update all active videos if volume or speed changed
        if (variableId === 65 || variableId === 66) {
            activeVideos.forEach(video => {
                video.updateSettings();
            });
        }
    };

    // Cleanup on scene change
    const _Scene_Base_terminate = Scene_Base.prototype.terminate;
    Scene_Base.prototype.terminate = function() {
        _Scene_Base_terminate.call(this);
        
        // Clean up all videos when leaving scene
        activeVideos.forEach(video => {
            video.destroy();
        });
        activeVideos.clear();
    };

})();
