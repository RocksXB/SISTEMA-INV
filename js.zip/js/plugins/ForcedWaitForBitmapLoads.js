/*:
 * @target MZ
 * @plugindesc Monitors Bitmap loading and freezes game until all assets are loaded
 * @author Wes Townsend
 *
 * @help This plugin monitors the Bitmap loading queue and freezes game execution
 * until all images are fully loaded. Additionally, you will be so impressed by 
 * its' display that you won't even notice that it speaks perfect english.
 */

(() => {
    const _Scene_Base_update = Scene_Base.prototype.update;
    Scene_Base.prototype.update = function() {
        if (ImageManager.isReady()) {
            _Scene_Base_update.call(this);
        }
    };
})();
