Game_CharacterBase.prototype.realMoveSpeed = function() {
    //return this._moveSpeed + (this.isDashing() ? 1 : 0);
	if ($gameSwitches.value(11)) {
		return this._moveSpeed + (this.isDashing() ? 1 : 0) + (this.isDashing() ? $gameVariables.value(500) : 0);
	} else {
		return this._moveSpeed + (this.isDashing() ? 1 : 0) + (this.isDashing() ? $gameVariables.value(60) : 0);
	}
	
};