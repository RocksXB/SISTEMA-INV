Sprite_Balloon.prototype.initMembers = function() {
    this._target = null;
    this._balloonId = 0;
    this._duration = 0;
    this.anchor.x = 0.5;   
	this.anchor.y = $gameVariables.value(68);
    this.z = 7;
};